﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int cotton = 1500;
        int Shirt = 1000;
        int trouser = 1200;
        int CoatSuit = 6500;
        int Sherwani = 6000;
        int jacket = 4500;
        int s1, s2, s3, s4, s5, s6 =0;
        int GrandTotal = 0;

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            s1 = cotton * Convert.ToInt32(textBox3.Text);
            
        }

        private void button6_Click(object sender, EventArgs e)
        {
            GrandTotal = s1 + s2 + s3 + s4 + s5 + s6;

            MessageBox.Show("Customer Name: " + textBox1.Text +
                 //Product Name  Quantity  Each Price   Product Total
                 "\n\nProductName \t Quantity \t EachPrice \t ProductTotal \n" +
                 "\nCotton    \t     " + textBox3.Text+"\t\t        "+cotton+"\t"+s1+
                 "\nShirt     \t\t     " + textBox4.Text + "\t\t        " + Shirt + "\t" + s2 +
                 "\nCoatSuit  \t     " + textBox6.Text + "\t\t        " + trouser + "\t" + s3 +
                 "\nCoatSuit  \t     " + textBox9.Text + "\t\t        " + CoatSuit + "\t" + s4 +
                 "\nSherwani  \t     " + textBox8.Text + "\t\t        " + Sherwani + "\t" + s5 +
                 "\nJacket    \t\t     " + textBox10.Text + "\t\t        " + jacket + "\t" + s6 +
                 "\n=============================================\n\n\n"+
                 "\t\t\t\t\t Grand Total:  "+GrandTotal);
            /*+ textBox3.Text+"\t"+ "" + cotton+"\t"+ "" + s1+
            "\nShirt" + textBox4.Text + "\t " + Shirt + "\t" + s2 +
            "\nTrouser" + textBox6.Text + "\t " + trouser + "\t" + s3 +
            "\nCoatSuit" + textBox9.Text + "\t " + CoatSuit + "\t" + s4 +
            "\nSherwani" + textBox8.Text + "\t " + Sherwani + "\t" + s5 +
            "\nJacket" + textBox10.Text + "\t " + jacket + "\t" + s6*/

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            s2 = Shirt * Convert.ToInt32(textBox4.Text);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            s3 = trouser * Convert.ToInt32(textBox6.Text);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            s4 = CoatSuit * Convert.ToInt32(textBox9.Text);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            s5 = Sherwani * Convert.ToInt32(textBox8.Text);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            s6 = jacket * Convert.ToInt32(textBox10.Text);
        }
    }
}
